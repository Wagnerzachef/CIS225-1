
/**
 * Write a description of class Heater here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Heater
{
    // instance variables - replace the example below with your own
    private double temperature;
    private double min;
    private double max;
    private double increment;

    /**
     * Constructor for objects of class Heater
     */
    public Heater(int maximum, int minimum)
    {
        temperature = 15;
        max = maximum;
        min = minimum;
        increment = 5;
        
    }
    
    /**
     * Method to check if temp is smallerthan max and change it to the temperature
     * plus the increment
     */
    public void warmer()
    {
        double newTemperature = temperature + increment;
        if(newTemperature <= max){
        temperature = newTemperature;
        }
    }
    
    /**
     * Make the temperature cooler but not below minimum
     */
    public void cooler()
    {
        double newTemperature = temperature - increment;
        if(newTemperature >= min){
            temperature = newTemperature;
        }
    }
    
    /**
     * Change the increment
     */
    public void setIncrement(int inc)
    {
        if(inc >= 0) {
            increment = inc;
        }
    }
    
    /**
     * Get the temperature
     */
    public double getTemperature()
    {
        return temperature;
    }
}
